// square.cpp
#include "square.h"

template<typename T> T square(T a)
{
	return a * a;
}