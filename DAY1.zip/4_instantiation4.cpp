#include <vector>

// 핵심 : class template 의 타입 추론은 C++17 부터 사용가능.

template<typename T>
T square(T a)
{
	return a * a;
}

template<typename T>
class List
{
public:
	List(int sz, const T& value) {}
};

int main()
{
	// function template
	square<int>(3);	// ?
	square(3);		// ?

	// class template
	List<int> s1(10, 3); // ?
	List      s2(10, 3); // ?

	std::vector<int> v1 = { 1,2,3 };
	std::vector      v2 = { 1,2,3 }; 
}

