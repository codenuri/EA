template<typename T>
struct Object
{
	using type = int;

	template<typename U>
	static void mf() {	}
};

template<typename T>
void foo()
{
	// 1. typename 
//	Object<int>::type t1;
//	Object<T>::type t2;	
	
	
	// 2. template
//	Object<int>::mf<double>();	
//	Object<T>::mf<double>();	


	Object<int> o1;
	Object<T>   o2;

//	o1.mf<double>();
//	o2.mf<double>();	
}

int main()
{
	foo<int>();
}