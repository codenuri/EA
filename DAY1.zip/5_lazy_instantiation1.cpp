// # 핵심 : lazy instantiation 개념

class Object
{
	int value;
public:
	void mf()
	{
		*value = 10; // ?
	}
};

int main()
{
	Object obj;
}
