#include <iostream>
#include "fname.h"

// 규칙 1. 함수 인자가 value type 인 경우

template<typename T> void f1(T arg)
{
	std::cout << _FNAME_ << std::endl;
}

int main()
{
	int  n = 10;
	int& r = n;
	const int  c = 10;
	const int& cr = c;

	f1(n);
	f1(c);
	f1(r);
	f1(cr);
}