#include <iostream>
#include <concepts>


template<typename T> 
T square(T a)
{
	std::cout << "integral" << std::endl;
	return a * a;
}

template<typename T> 
T square(T a)
{
	std::cout << "not integral" << std::endl;
	return a * a;
}

int main()
{
	square(3);
	square(3.4);
	square(3.4f); // float 도 실수 계열이므로 아래 버전 사용

}