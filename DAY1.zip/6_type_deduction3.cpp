#include <iostream>
#include "fname.h"

// 규칙 2. 함수 인자가 lvalue reference 인 경우
template<typename T> void f2(T& arg)
{
	std::cout << _FNAME_ << std::endl;
}

int main()
{
	int  n = 10;
	int& r = n;
	const int  c = 10;
	const int& cr = c;

	f2(n);
	f2(c);
	f2(r);
	f2(cr);
}