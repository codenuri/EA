#include <iostream>
#include "fname.h"

template<typename T>
void fn(T arg)
{
	while (--arg) {};
}

int main()
{
	int 	n = 10;
	double 	d = 3.4;
	const int c = 10;

	fn<int>(3);	// T=
	fn(n);		// 
	fn(d);		//	
	fn(c);		// 
}