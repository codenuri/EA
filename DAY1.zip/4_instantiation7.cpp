#include <iostream>
#include <functional>
#include <type_traits> // std::type_identity

// # 핵심 : type_identity 개념

template<typename T> void foo(T a)
{
}

template<typename T> void goo(T a)
{
}

int main()
{
	foo(10);		// ok
	foo<int>(10);	// ok

	goo(10);	  // ok
	goo<int>(10); // ok
}