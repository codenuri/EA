#include <vector>
#include <list>

// # 핵심 : C++17 "class template type deduction guide" 문법

template<typename T>
class List
{
public:
	List() {}
	List(int sz, const T& value) {}
};


int main()
{
	List<int> s1(10, 3);
	List      s2(10, 3);
	List<int> s3;
	List      s4; 

//	std::vector v = { 1,2,3 };
//	List s5(v); // ?

//	List s6(v.begin(), v.end());
}

