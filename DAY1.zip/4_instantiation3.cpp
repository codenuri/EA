#include <iostream>
#include "square.h"	

// # 핵심 : template 과 파일 분할, explicit instantiation
// square.h square.cpp 소스 참고

int main()
{
	square(3);
	square(3.3);
}

