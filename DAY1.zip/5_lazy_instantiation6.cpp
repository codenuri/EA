
// 아래 코드는 에러가 있을까요 ?
template<typename T>
void fn(T value)
{
	if ( false )
		*value = 10;
}

int main()
{
	int n = 10;
	fn(n);
}
