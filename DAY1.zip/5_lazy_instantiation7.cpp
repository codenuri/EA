// 템플릿은 틀 입니다.
// 사용한 경우만 인스턴스화 됩니다.
template<typename T> void fn(T value, int)
{
	*value = 10;
}

template<typename T> void fn(T value, double)
{
}

int main()
{
	fn(1, 3);	

//	fn(1, 3.3);	
}