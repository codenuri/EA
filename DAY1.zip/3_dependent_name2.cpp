// # 핵심 : typename 과 template 키워드

struct Object
{
	using type = int;

	static constexpr int value = 10;

	template<typename T> struct rebind
	{
	};
};

template<typename T>
void foo(T obj)
{
	Object::value * 10;
	Object::type  * p1;

	T::value * 10;
	T::type  * p1;

	Object::rebind<int> r1; // ?

	T::rebind<int> r2; // ?
}




int main()
{
	Object obj;
	foo(obj);
}