#include <iostream>

// 핵심 #1 "template instantiation(템플릿 인스턴스화)" 용어
// => 템플릿(틀) 로 부터 실제 "함수/클래스"를 만드는 과정

// 핵심 #2. instantiation 결과를 확인하는 방법
// => 1. godbolt.org 에서 어셈블리 코드 확인
// => 2. 함수의 이름 출력


template<typename T>
T square(T a)
{

	return a * a;
}

int main()
{
	square<int>(3);			
	square<double>(3.3);
	square(3);
}

