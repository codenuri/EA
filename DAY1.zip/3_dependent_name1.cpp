// 핵심 : dependent name 의 개념과 typename 키워드

struct Object
{
	using type = int;
	static constexpr int value = 10;
};

template<typename T>
void foo(T obj)
{
	// 아래 코드에서 * 연산자의 의미를 생각해 보세요
	Object::value * 10;
	Object::type  * p1;
	
}


int main()
{
	Object obj;
	foo(obj);
}