#include <type_traits>

// # 핵심 : template 을 만드는 방법

// #1. typename 또는 class 키워드
template<typename T>
T square(T a)
{
	return a * a;
}


// #2. auto : C++20 ~ 



// #3. requires clauses : C++20 ~



int main()
{

}
