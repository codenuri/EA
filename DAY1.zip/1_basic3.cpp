#include <iostream>

// # 핵심 : square vs square<int>

// square      : 
// square<int> : 

template<typename T>
T square(T a)
{
	return a * a;
}

int main()
{
	printf("%p\n", &square);	// ?

	auto p1 = &square;			// ?
}

